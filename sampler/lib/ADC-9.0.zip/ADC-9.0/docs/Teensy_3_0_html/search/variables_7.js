var searchData=
[
  ['pg_317',['PG',['../struct_a_d_c__settings_1_1_a_d_c___r_e_g_s__t.html#a63537e0272e98f3506952e2e7de4e500',1,'ADC_settings::ADC_REGS_t']]],
  ['pga_318',['PGA',['../struct_a_d_c__settings_1_1_a_d_c___r_e_g_s__t.html#aecfae9b52d259cf8e544266ef4a3927c',1,'ADC_settings::ADC_REGS_t']]]
];
