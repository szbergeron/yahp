var searchData=
[
  ['diff_5ftable_5fadc0_40',['diff_table_ADC0',['../class_a_d_c.html#a1b2c46ade5591fb8038961fb352506a3',1,'ADC']]],
  ['differentialmode_41',['differentialMode',['../class_a_d_c___module.html#adaba2c3f43e9c702a873da6539b3d25f',1,'ADC_Module']]],
  ['disablecompare_42',['disableCompare',['../class_a_d_c___module.html#ac635f675a9690a4db016c73c31818262',1,'ADC_Module']]],
  ['disabledma_43',['disableDMA',['../class_a_d_c___module.html#ac1610dcab46476f287c2dd4d96465c47',1,'ADC_Module']]],
  ['disableinterrupts_44',['disableInterrupts',['../class_a_d_c___module.html#aa4509062644982526fee3c02e0b528fc',1,'ADC_Module']]]
];
