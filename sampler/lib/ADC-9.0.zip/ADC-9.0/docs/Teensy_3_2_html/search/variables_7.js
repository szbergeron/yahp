var searchData=
[
  ['sampling_5fspeed_5flist_237',['sampling_speed_list',['../namespace_a_d_c__util.html#ad813ee6b28ef93d8bc7d0c3bf62b967b',1,'ADC_util']]],
  ['savedsc1a_238',['savedSC1A',['../struct_a_d_c___module_1_1_a_d_c___config.html#a708e83c3bbd11a06d88802b8941e19a8',1,'ADC_Module::ADC_Config']]],
  ['sc1a2channeladc0_239',['sc1a2channelADC0',['../class_a_d_c.html#a4377c680975fe754de24b8f8617042de',1,'ADC']]],
  ['sc1a2channeladc1_240',['sc1a2channelADC1',['../class_a_d_c.html#a34e8ad9674e566e5ad7e0187e4393fcd',1,'ADC']]]
];
