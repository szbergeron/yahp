var searchData=
[
  ['high_5fspeed_214',['HIGH_SPEED',['../namespace_a_d_c__settings.html#aab853fc1fcb1992fd5d51408adf7688ea78f3e093707596168b9993c4f6f8ae10',1,'ADC_settings::HIGH_SPEED()'],['../namespace_a_d_c__settings.html#af0d80a1aae7288f77b13f0e01d9da0d3a78f3e093707596168b9993c4f6f8ae10',1,'ADC_settings::HIGH_SPEED()']]],
  ['high_5fspeed_5f16bits_215',['HIGH_SPEED_16BITS',['../namespace_a_d_c__settings.html#aab853fc1fcb1992fd5d51408adf7688eac89070efb9f2a03d57915d92e251f9fd',1,'ADC_settings']]]
];
