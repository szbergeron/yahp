var _v_r_e_f_8h =
[
    [ "isOn", "_v_r_e_f_8h.html#ab1becdab4311ae08f2eb56e2542e9eb1", null ],
    [ "isStable", "_v_r_e_f_8h.html#a7a17a24c68ffc761a61750dd5c207336", null ],
    [ "start", "_v_r_e_f_8h.html#a569b07fd4d9cba8e5c6cb170b952c7ef", null ],
    [ "stop", "_v_r_e_f_8h.html#ac667e62e25fd2c9325f73dd0c6a6a3e8", null ],
    [ "trim", "_v_r_e_f_8h.html#adf9a5a3b3d7140ad45019141c2f054b4", null ],
    [ "waitUntilStable", "_v_r_e_f_8h.html#a108f7c1b5a2073bc092eafcae58575b0", null ]
];