var searchData=
[
  ['temp_5fsensor_223',['TEMP_SENSOR',['../namespace_a_d_c__settings.html#a8c2a64f3fca3ac6b82e8df8cf44f6ca2a2d8001cb5670d5668694dbf8697ee69f',1,'ADC_settings']]]
];
