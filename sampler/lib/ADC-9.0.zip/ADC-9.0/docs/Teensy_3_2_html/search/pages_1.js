var searchData=
[
  ['license_224',['LICENSE',['../md__c_1__users_pedvi__projects__a_d_c__l_i_c_e_n_s_e.html',1,'']]]
];
