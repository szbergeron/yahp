var searchData=
[
  ['med_5fspeed_217',['MED_SPEED',['../namespace_a_d_c__settings.html#aab853fc1fcb1992fd5d51408adf7688ea9d9b800360e0fb88ba3d964b0b30feba',1,'ADC_settings::MED_SPEED()'],['../namespace_a_d_c__settings.html#af0d80a1aae7288f77b13f0e01d9da0d3a9d9b800360e0fb88ba3d964b0b30feba',1,'ADC_settings::MED_SPEED()']]]
];
