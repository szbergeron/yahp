var searchData=
[
  ['getconversionenumstr_50',['getConversionEnumStr',['../namespace_a_d_c__util.html#ab6104e4e363b1fecb3b9158ee8bee37b',1,'ADC_util']]],
  ['getmaxvalue_51',['getMaxValue',['../class_a_d_c___module.html#af3704819ccda64bae9c13a95a74e70a8',1,'ADC_Module']]],
  ['getpdbfrequency_52',['getPDBFrequency',['../class_a_d_c___module.html#ae113f4168d9dd343f66ecc6e59a245f6',1,'ADC_Module']]],
  ['getresolution_53',['getResolution',['../class_a_d_c___module.html#a58cabc09d41f6aa25319fd514b47c48f',1,'ADC_Module']]],
  ['getsamplingenumstr_54',['getSamplingEnumStr',['../namespace_a_d_c__util.html#ab07f137e89f16be8bfb6e05c8bba8905',1,'ADC_util']]],
  ['getstringadcerror_55',['getStringADCError',['../namespace_a_d_c__util.html#a0414ae3ca07a90b40e0515956ca0e49d',1,'ADC_util']]],
  ['gettimerfrequency_56',['getTimerFrequency',['../class_a_d_c___module.html#ae3c47b374f4f68eb815812c6a373e439',1,'ADC_Module']]]
];
