var namespaces_dup =
[
    [ "ADC_Error", "namespace_a_d_c___error.html", null ],
    [ "ADC_settings", "namespace_a_d_c__settings.html", null ],
    [ "ADC_util", "namespace_a_d_c__util.html", null ],
    [ "VREF", "namespace_v_r_e_f.html", null ]
];