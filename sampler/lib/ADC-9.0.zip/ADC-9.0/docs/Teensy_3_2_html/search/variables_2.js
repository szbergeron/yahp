var searchData=
[
  ['diff_5ftable_5fadc0_228',['diff_table_ADC0',['../class_a_d_c.html#a1b2c46ade5591fb8038961fb352506a3',1,'ADC']]],
  ['diff_5ftable_5fadc1_229',['diff_table_ADC1',['../class_a_d_c.html#a1a12d4789bc90eea4ed115f8f7f0b457',1,'ADC']]]
];
