var searchData=
[
  ['ra_319',['RA',['../struct_a_d_c__settings_1_1_a_d_c___r_e_g_s__t.html#aefcb96d5c0352ff6cb1b07a01efbc9ac',1,'ADC_settings::ADC_REGS_t']]],
  ['rb_320',['RB',['../struct_a_d_c__settings_1_1_a_d_c___r_e_g_s__t.html#adac5470b8b7b29a3bf084e52f157abf1',1,'ADC_settings::ADC_REGS_t']]],
  ['resolutions_5flist_321',['resolutions_list',['../namespace_a_d_c__util.html#a1f7a8c6dcdadcb5dd43a77de9a380bb0',1,'ADC_util']]]
];
