var struct_a_d_c_1_1_sync__result =
[
    [ "result_adc0", "struct_a_d_c_1_1_sync__result.html#aa523cf5b3ed9823c0ff672a4b8eb3f4e", null ],
    [ "result_adc1", "struct_a_d_c_1_1_sync__result.html#a652c42a16111d4edeb3cd7b324b382c7", null ]
];